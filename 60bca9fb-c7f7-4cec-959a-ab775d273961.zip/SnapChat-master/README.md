# SnapChat Clone

This is a web based SnapChat Clone which is a work in progress 

#### Current features

  - UI Recreation
  - Login Script
  - Stories
  - Chat

#### Coming Features!

  - Finish Register Page UI
  - Add Register Script
  - Add Friends
  - Add Search
  - Add Proper Account System
  - Add Snaps
  
# Credits

 - UI: SnapChat
 - Clone: JosephShenton